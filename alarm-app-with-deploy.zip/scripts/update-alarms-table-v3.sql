-- Add mission_type column to alarms table
ALTER TABLE alarms
ADD COLUMN mission_type TEXT DEFAULT 'none'; -- 'none', 'math', 'shake'
