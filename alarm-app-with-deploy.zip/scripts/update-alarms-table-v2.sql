-- Add voice_memo_url column to alarms table
ALTER TABLE alarms
ADD COLUMN voice_memo_url TEXT;

-- Create a storage bucket for alarm voice memos
-- You need to run this command in your Supabase SQL Editor if the bucket doesn't exist
-- INSERT INTO storage.buckets (id, name, public) VALUES ('alarm-memos', 'alarm-memos', true);

-- Set up RLS policies for the new storage bucket (if you create it manually)
-- Policy for authenticated users to upload files
-- CREATE POLICY "Allow authenticated users to upload voice memos"
-- ON storage.objects FOR INSERT TO authenticated
-- WITH CHECK (bucket_id = 'alarm-memos' AND auth.uid() IS NOT NULL);

-- Policy for authenticated users to view their own voice memos
-- CREATE POLICY "Allow authenticated users to view their own voice memos"
-- ON storage.objects FOR SELECT TO authenticated
-- USING (bucket_id = 'alarm-memos' AND auth.uid() IS NOT NULL);
