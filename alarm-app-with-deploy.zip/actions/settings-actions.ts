"use server"

import { supabase } from "@/lib/supabase"
import { revalidatePath } from "next/cache"

/**
 * Updates the user's profile information (username, full_name, email).
 * @param userId The ID of the user to update.
 * @param updates An object containing the fields to update.
 * @returns A success or error message.
 */
export async function updateUserProfile(
  userId: string,
  updates: { username?: string | null; full_name?: string | null; email?: string | null },
) {
  const { data: existingProfile, error: fetchError } = await supabase
    .from("user_profiles")
    .select("username, email")
    .eq("id", userId)
    .single()

  if (fetchError || !existingProfile) {
    console.error("Error fetching user profile:", fetchError?.message)
    return { success: false, message: "User profile not found." }
  }

  // Check if username is being updated and if it's already taken by another user
  if (updates.username && updates.username !== existingProfile.username) {
    const { data: existingUsername, error: usernameCheckError } = await supabase
      .from("user_profiles")
      .select("id")
      .eq("username", updates.username)
      .neq("id", userId) // Exclude current user
      .single()

    if (existingUsername) {
      return { success: false, message: "Username already taken." }
    }
  }

  // If email is being updated, first update it in auth.users
  if (updates.email && updates.email !== existingProfile.email) {
    // Check if the new email is already in use by another account
    const { data: existingUserByEmail } = await supabase.auth.admin.getUserByEmail(updates.email)
    if (existingUserByEmail?.user && existingUserByEmail.user.id !== userId) {
      return { success: false, message: "Email already in use by another account." }
    }

    const { error: authUpdateError } = await supabase.auth.admin.updateUserById(userId, { email: updates.email })
    if (authUpdateError) {
      console.error("Error updating auth email:", authUpdateError.message)
      return { success: false, message: `Failed to update email: ${authUpdateError.message}` }
    }
  }

  // Update user_profiles table
  const { error } = await supabase
    .from("user_profiles")
    .update({
      username: updates.username,
      full_name: updates.full_name,
      email: updates.email, // Update email in profile too for consistency
      updated_at: new Date().toISOString(),
    })
    .eq("id", userId)

  if (error) {
    console.error("Error updating user profile:", error.message)
    return { success: false, message: `Failed to update profile: ${error.message}` }
  }

  revalidatePath("/") // Revalidate to show updated profile info
  return { success: true, message: "Profile updated successfully!" }
}

/**
 * Initiates a password reset flow by sending a reset email to the user.
 * @param email The email address to send the reset link to.
 * @returns A success or error message.
 */
export async function initiatePasswordReset(email: string) {
  const { error } = await supabase.auth.resetPasswordForEmail(email, {
    redirectTo: `${process.env.NEXT_PUBLIC_VERCEL_URL}/update-password`, // Redirect to a page where user can set new password
  })

  if (error) {
    console.error("Error initiating password reset:", error.message)
    return { success: false, message: `Failed to send reset email: ${error.message}` }
  }

  return { success: true, message: "Password reset email sent! Check your inbox." }
}

/**
 * Deletes a user account permanently.
 * NOTE: This action requires Supabase Admin privileges. In a production app,
 * you might want to use a more secure server-side function or a different
 * approach for user-initiated account deletion.
 * @param userId The ID of the user account to delete.
 * @returns A success or error message.
 */
export async function deleteUserAccount(userId: string) {
  const { error } = await supabase.auth.admin.deleteUser(userId)

  if (error) {
    console.error("Error deleting user account:", error.message)
    return { success: false, message: `Failed to delete account: ${error.message}` }
  }

  // After deleting the user, the client-side will handle logging out and redirecting.
  revalidatePath("/")
  // No redirect here, let the client handle it after successful logout.
  return { success: true, message: "Account deleted successfully." }
}
