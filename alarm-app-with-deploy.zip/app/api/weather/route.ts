import { NextResponse } from "next/server"

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const lat = searchParams.get("lat")
  const lon = searchParams.get("lon")

  if (!lat || !lon) {
    return NextResponse.json({ error: "Latitude and longitude are required" }, { status: 400 })
  }

  const apiKey = process.env.OPENWEATHER_API_KEY // Ensure this env var is set on Vercel
  if (!apiKey) {
    return NextResponse.json({ error: "OpenWeather API key not configured" }, { status: 500 })
  }

  try {
    const weatherResponse = await fetch(
      `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${apiKey}&units=metric`,
    )
    const weatherData = await weatherResponse.json()

    if (!weatherResponse.ok) {
      console.error("OpenWeather API error:", weatherData)
      return NextResponse.json(
        { error: weatherData.message || "Failed to fetch weather" },
        { status: weatherResponse.status },
      )
    }

    return NextResponse.json(weatherData)
  } catch (error) {
    console.error("Server error fetching weather:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
