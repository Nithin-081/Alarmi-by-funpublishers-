# Alarm App – Cloudflare Deploy

This is an advanced alarm app built with Next.js, TypeScript, Tailwind, Supabase backend and features like:
- Multiple alarms
- Smart snooze (shake/math mission)
- Gamified wake-up streaks, coins & badges
- In-app shop to buy new sounds & themes
- Cloud sync, user profiles, beautiful UI

## 🚀 Deploy to Cloudflare (static assets)

For pure static parts (like /public):

1. Install Wrangler CLI
```bash
npm install -g wrangler
```

2. Deploy:
```bash
npx wrangler deploy --assets=./public
```

## ⚡ Deploy full Next.js app

Use Vercel (recommended) or Netlify:

### Vercel
1. Push to GitHub
2. Go to https://vercel.com/import
3. Connect repo → done!

### Netlify
1. Push to GitHub
2. Go to https://app.netlify.com/start
3. Connect repo → done!

Your app will be live with a free .vercel.app or .netlify.app domain.