"use client"

import { useState, useEffect, useCallback, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Plus,
  Clock,
  Volume2,
  VolumeX,
  Bed,
  Mic,
  StopCircle,
  Play,
  XCircle,
  Coins,
  Settings,
  Gift,
  CheckCircle,
  Loader2,
} from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlarmiLogo } from "./components/alarmi-logo"
import { AuthForm } from "./components/auth/auth-form"
import { UserMenu } from "./components/user-menu"
import { supabase } from "./lib/supabase"
import type { User } from "@supabase/supabase-js"
import { ThemeProvider } from "next-themes"
import { ThemeToggle } from "./components/theme-toggle"
import { MathMission } from "./components/math-mission"
import { ShakeMission } from "./components/shake-mission"
import { AlarmCalendar } from "./components/alarm-calendar"
import { updateUserCoins, claimDailyBonus } from "@/actions/user-actions"
import { Shop } from "./components/shop"
import { SettingsDialog } from "./components/settings-dialog"

interface Alarm {
  id: string
  time: string
  label: string
  is_active: boolean
  hour: number
  minute: number
  period: "AM" | "PM"
  user_id: string
  last_triggered_at: string | null
  voice_memo_url: string | null
  mission_type: "none" | "math" | "shake" | null
}

interface UserProfile {
  id: string
  username: string | null
  email: string | null
  full_name: string | null
  coins: number
  unlocked_missions: string[] | null
  unlocked_premium_tones: boolean
  has_daily_bonus_feature: boolean
  last_daily_bonus_claim: string | null
  unlocked_backgrounds: string[] | null
}

interface WeatherData {
  name: string
  main: {
    temp: number
    feels_like: number
  }
  weather: {
    description: string
    icon: string
  }[]
}

export default function AlarmAppContent() {
  const [user, setUser] = useState<User | null>(null)
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null)
  const [loading, setLoading] = useState(true)
  const [currentTime, setCurrentTime] = useState(new Date())
  const [alarms, setAlarms] = useState<Alarm[]>([])
  const [newAlarmHour, setNewAlarmHour] = useState("12")
  const [newAlarmMinute, setNewAlarmMinute] = useState("00")
  const [newAlarmPeriod, setNewAlarmPeriod] = useState<"AM" | "PM">("AM")
  const [newAlarmLabel, setNewAlarmLabel] = useState("")
  const [newAlarmMissionType, setNewAlarmMissionType] = useState<"none" | "math" | "shake">("none")
  const [triggeringAlarm, setTriggeringAlarm] = useState<Alarm | null>(null)
  const [audioContext, setAudioContext] = useState<AudioContext | null>(null)
  const [gainNode, setGainNode] = useState<GainNode | null>(null)
  const [oscillator, setOscillator] = useState<OscillatorNode | null>(null)
  const [isMissionActive, setIsMissionActive] = useState(false)
  const [weatherData, setWeatherData] = useState<WeatherData | null>(null)
  const [wakeUpHour, setWakeUpHour] = useState("07")
  const [wakeUpMinute, setNewWakeUpMinute] = useState("00")
  const [wakeUpPeriod, setWakeUpPeriod] = useState<"AM" | "PM">("AM")
  const [suggestedBedtime, setSuggestedBedtime] = useState<string | null>(null)
  const [showShop, setShowShop] = useState(false)
  const [isSettingsOpen, setIsSettingsOpen] = useState(false)

  // Voice Memo States
  const [isRecording, setIsRecording] = useState(false)
  const [recordedAudioBlob, setRecordedAudioBlob] = useState<Blob | null>(null)
  const [recordedAudioUrl, setRecordedAudioUrl] = useState<string | null>(null)
  const mediaRecorderRef = useRef<MediaRecorder | null>(null)
  const audioChunksRef = useRef<Blob[]>([])
  const audioPlayerRef = useRef<HTMLAudioElement | null>(null)

  // Gradual Brightness State
  const [brightnessLevel, setBrightnessLevel] = useState(100)

  // Daily Bonus State
  const [dailyBonusMessage, setDailyBonusMessage] = useState<{ type: "error" | "success"; text: string } | null>(null)
  const [isClaimingBonus, setIsClaimingBonus] = useState(false)

  // Check authentication status
  useEffect(() => {
    const getSession = async () => {
      const {
        data: { session },
      } = await supabase.auth.getSession()
      setUser(session?.user ?? null)
      setLoading(false)
      console.log("Auth: Initial session check. User:", session?.user ? "logged in" : "null")
    }

    getSession()

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange(async (event, session) => {
      setUser(session?.user ?? null)
      setLoading(false)
      console.log("Auth: State changed to", event, ". User:", session?.user ? "logged in" : "null")
    })

    return () => subscription.unsubscribe()
  }, [])

  // Load user's alarms and profile
  useEffect(() => {
    const loadUserData = async () => {
      if (!user) {
        setAlarms([])
        setUserProfile(null)
        console.log("Data Load: User is null, clearing alarms and profile.")
        return
      }

      // For real user, load from Supabase
      const { data: alarmsData, error: alarmsError } = await supabase
        .from("alarms")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false })

      if (alarmsError) {
        console.error("Error loading alarms:", alarmsError)
      } else {
        setAlarms(alarmsData || [])
        console.log("Data Load: Alarms loaded for real user.", alarmsData)
      }

      const { data: profileData, error: profileError } = await supabase
        .from("user_profiles")
        .select("*")
        .eq("id", user.id)
        .single()

      if (profileError) {
        console.error("Error loading user profile:", profileError)
      } else {
        setUserProfile(profileData || null)
        console.log("Data Load: User profile loaded for real user.", profileData)
      }
    }

    loadUserData()
  }, [user])

  // Initialize audio context
  useEffect(() => {
    const initAudio = () => {
      if (typeof window !== "undefined") {
        const ctx = new (window.AudioContext || (window as any).webkitAudioContext)()
        const gn = ctx.createGain()
        gn.connect(ctx.destination)
        setAudioContext(ctx)
        setGainNode(gn)
      }
    }
    initAudio()
  }, [])

  // Update current time every second
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date())
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  // Play alarm sound with fade-in or voice memo
  const playAlarmSound = useCallback(
    (alarmToPlay: Alarm) => {
      stopAlarmSound() // Ensure any previous sound is stopped

      if (alarmToPlay.voice_memo_url && audioPlayerRef.current) {
        audioPlayerRef.current.src = alarmToPlay.voice_memo_url
        audioPlayerRef.current.loop = true // Loop voice memo
        audioPlayerRef.current.play().catch((e) => console.error("Error playing voice memo:", e))
      } else if (audioContext && gainNode) {
        const newOscillator = audioContext.createOscillator()
        newOscillator.connect(gainNode)

        newOscillator.frequency.setValueAtTime(800, audioContext.currentTime)
        newOscillator.type = "sine"

        // Fade in effect
        gainNode.gain.setValueAtTime(0, audioContext.currentTime)
        gainNode.gain.linearRampToValueAtTime(0.3, audioContext.currentTime + 3) // Fade in over 3 seconds

        newOscillator.start(audioContext.currentTime)
        newOscillator.stop(audioContext.currentTime + 30) // Play for max 30 seconds if not dismissed

        setOscillator(newOscillator)
      }
    },
    [audioContext, gainNode, oscillator],
  )

  // Stop alarm sound
  const stopAlarmSound = useCallback(() => {
    if (oscillator) {
      oscillator.stop()
      oscillator.disconnect()
      setOscillator(null)
    }
    if (gainNode) {
      gainNode.gain.cancelScheduledValues(audioContext!.currentTime)
      gainNode.gain.setValueAtTime(0, audioContext!.currentTime)
    }
    if (audioPlayerRef.current) {
      audioPlayerRef.current.pause()
      audioPlayerRef.current.currentTime = 0
      audioPlayerRef.current.src = "" // Clear source
    }
  }, [oscillator, gainNode, audioContext])

  // Gradual Brightness Effect
  useEffect(() => {
    let brightnessInterval: NodeJS.Timeout | null = null
    if (triggeringAlarm) {
      setBrightnessLevel(50) // Start from dimmer
      let currentBrightness = 50
      brightnessInterval = setInterval(() => {
        currentBrightness += 5
        if (currentBrightness >= 100) {
          currentBrightness = 100
          if (brightnessInterval) clearInterval(brightnessInterval)
        }
        setBrightnessLevel(currentBrightness)
      }, 200) // Increase brightness every 200ms
    } else {
      setBrightnessLevel(100) // Reset to full brightness
      if (brightnessInterval) clearInterval(brightnessInterval)
    }
    return () => {
      if (brightnessInterval) clearInterval(brightnessInterval)
    }
  }, [triggeringAlarm])

  // Check for triggered alarms
  useEffect(() => {
    const checkAlarms = async () => {
      if (isMissionActive) return // Don't trigger new alarms if one is active

      const now = new Date()
      const currentHour = now.getHours()
      const currentMinute = now.getMinutes()
      const currentSecond = now.getSeconds()

      // Only check at the start of each minute
      if (currentSecond !== 0) return

      for (const alarm of alarms) {
        if (!alarm.is_active) continue

        let alarmHour = alarm.hour
        if (alarm.period === "PM" && alarm.hour !== 12) {
          alarmHour += 12
        } else if (alarm.period === "AM" && alarm.hour === 12) {
          alarmHour = 0
        }

        if (currentHour === alarmHour && currentMinute === alarm.minute) {
          setTriggeringAlarm(alarm)
          playAlarmSound(alarm) // Pass the alarm to playAlarmSound
          setIsMissionActive(true) // Activate mission

          // Update last_triggered_at in DB
          if (user) {
            await supabase.from("alarms").update({ last_triggered_at: new Date().toISOString() }).eq("id", alarm.id)
          }
          // Update local state immediately
          setAlarms((prev) =>
            prev.map((a) => (a.id === alarm.id ? { ...a, last_triggered_at: new Date().toISOString() } : a)),
          )
          break // Only trigger one alarm at a time
        }
      }
    }

    checkAlarms()
  }, [currentTime, alarms, playAlarmSound, isMissionActive, user])

  // Fetch weather data
  useEffect(() => {
    const fetchWeather = async () => {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(async (position) => {
          const { latitude, longitude } = position.coords
          try {
            const response = await fetch(`/api/weather?lat=${latitude}&lon=${longitude}`)
            if (response.ok) {
              const data = await response.json()
              setWeatherData(data)
            } else {
              console.error("Failed to fetch weather:", await response.json())
            }
          } catch (error) {
            console.error("Error fetching weather:", error)
          }
        })
      }
    }
    fetchWeather()
  }, [])

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString("en-US", {
      hour12: true,
      hour: "numeric",
      minute: "2-digit",
      second: "2-digit",
    })
  }

  const formatDate = (date: Date) => {
    return date.toLocaleDateString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      const mediaRecorder = new MediaRecorder(stream)
      mediaRecorderRef.current = mediaRecorder
      audioChunksRef.current = []

      mediaRecorder.ondataavailable = (event) => {
        audioChunksRef.current.push(event.data)
      }

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: "audio/webm" })
        setRecordedAudioBlob(audioBlob)
        const url = URL.createObjectURL(audioBlob)
        setRecordedAudioUrl(url)
        stream.getTracks().forEach((track) => track.stop()) // Stop microphone
      }

      mediaRecorder.start()
      setIsRecording(true)
      setRecordedAudioBlob(null)
      setRecordedAudioUrl(null)
    } catch (err) {
      console.error("Error accessing microphone:", err)
      alert("Could not access microphone. Please ensure permissions are granted.")
    }
  }

  const stopRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === "recording") {
      mediaRecorderRef.current.stop()
      setIsRecording(false)
    }
  }

  const playRecordedAudio = () => {
    if (recordedAudioUrl && audioPlayerRef.current) {
      audioPlayerRef.current.play().catch((e) => console.error("Error playing recorded audio:", e))
    }
  }

  const clearRecordedAudio = () => {
    if (recordedAudioUrl) {
      URL.revokeObjectURL(recordedAudioUrl)
    }
    setRecordedAudioBlob(null)
    setRecordedAudioUrl(null)
    if (audioPlayerRef.current) {
      audioPlayerRef.current.pause()
      audioPlayerRef.current.currentTime = 0
      audioPlayerRef.current.src = ""
    }
  }

  const addAlarm = async () => {
    if (!newAlarmHour || !newAlarmMinute || !user) return

    const hour = Number.parseInt(newAlarmHour)
    const minute = Number.parseInt(newAlarmMinute)
    const timeString = `${hour}:${minute.toString().padStart(2, "0")} ${newAlarmPeriod}`

    let voiceMemoUrl: string | null = null
    if (recordedAudioBlob) {
      // Upload voice memo to Supabase Storage
      const filePath = `${user.id}/${Date.now()}.webm`
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from("alarm-memos") // Ensure this bucket exists in Supabase Storage
        .upload(filePath, recordedAudioBlob, {
          cacheControl: "3600",
          upsert: false,
        })

      if (uploadError) {
        console.error("Error uploading voice memo:", uploadError)
        alert("Failed to upload voice memo. Alarm added without memo.")
      } else {
        const { data: publicUrlData } = supabase.storage.from("alarm-memos").getPublicUrl(filePath)
        voiceMemoUrl = publicUrlData.publicUrl
      }
    }

    const newAlarmData = {
      user_id: user.id,
      time: timeString,
      label: newAlarmLabel || "Alarm",
      is_active: true,
      hour,
      minute,
      period: newAlarmPeriod,
      voice_memo_url: voiceMemoUrl,
      mission_type: newAlarmMissionType, // Include selected mission type
    }

    // Insert into Supabase
    const { data, error } = await supabase.from("alarms").insert([newAlarmData]).select().single()

    if (error) {
      console.error("Error adding alarm:", error)
      return
    }
    setAlarms((prev) => [data, ...prev])

    setNewAlarmLabel("")
    clearRecordedAudio() // Clear recorded audio after adding alarm
    setNewAlarmMissionType("none") // Reset mission type
  }

  const toggleAlarm = async (id: string) => {
    const alarm = alarms.find((a) => a.id === id)
    if (!alarm) return

    // Update Supabase
    const { error } = await supabase.from("alarms").update({ is_active: !alarm.is_active }).eq("id", id)

    if (error) {
      console.error("Error toggling alarm:", error)
      return
    }

    // Update local state
    setAlarms((prev) => prev.map((a) => (a.id === id ? { ...a, is_active: !a.is_active } : a)))
  }

  const deleteAlarm = async (id: string) => {
    const alarmToDelete = alarms.find((a) => a.id === id)

    // Delete from Supabase
    const { error } = await supabase.from("alarms").delete().eq("id", id)

    if (error) {
      console.error("Error deleting alarm:", error)
      return
    }

    // If there was a voice memo, delete it from storage
    if (alarmToDelete?.voice_memo_url) {
      const filePath = alarmToDelete.voice_memo_url.split("alarm-memos/")[1]
      if (filePath) {
        const { error: storageError } = await supabase.storage.from("alarm-memos").remove([filePath])
        if (storageError) {
          console.error("Error deleting voice memo from storage:", storageError)
        }
      }
    }

    // Update local state
    setAlarms((prev) => prev.filter((alarm) => alarm.id !== id))
  }

  const dismissAlarm = async () => {
    stopAlarmSound()
    if (triggeringAlarm) {
      // Award coins if a mission was completed
      if (user && triggeringAlarm.mission_type !== "none") {
        const COINS_EARNED_PER_MISSION = 10
        const { success, message } = await updateUserCoins(user.id, COINS_EARNED_PER_MISSION)
        if (success) {
          console.log(message)
          // Update local userProfile state
          setUserProfile((prev) => (prev ? { ...prev, coins: prev.coins + COINS_EARNED_PER_MISSION } : null))
        } else {
          console.error("Failed to award coins:", message)
        }
      }

      // Optionally deactivate the alarm after dismissal
      await toggleAlarm(triggeringAlarm.id)
    }
    setTriggeringAlarm(null)
    setIsMissionActive(false)
  }

  const snoozeAlarm = async () => {
    stopAlarmSound()
    if (triggeringAlarm && user) {
      // Add 5 minutes to current time for snooze
      const now = new Date()
      now.setMinutes(now.getMinutes() + 5)

      const snoozeHour = now.getHours()
      const snoozeMinute = now.getMinutes()
      const snoozePeriod = snoozeHour >= 12 ? "PM" : "AM"
      const displayHour = snoozeHour > 12 ? snoozeHour - 12 : snoozeHour === 0 ? 12 : snoozeHour

      const snoozeAlarmData = {
        user_id: user.id,
        time: `${displayHour}:${snoozeMinute.toString().padStart(2, "0")} ${snoozePeriod}`,
        label: `${triggeringAlarm.label} (Snoozed)`,
        is_active: true,
        hour: displayHour,
        minute: snoozeMinute,
        period: snoozePeriod,
        voice_memo_url: triggeringAlarm.voice_memo_url, // Carry over voice memo
        mission_type: triggeringAlarm.mission_type, // Carry over mission type
      }

      // Insert into Supabase
      const { data, error } = await supabase.from("alarms").insert([snoozeAlarmData]).select().single()

      if (!error && data) {
        setAlarms((prev) => [data, ...prev])
      }
    }
    setTriggeringAlarm(null)
    setIsMissionActive(false)
  }

  const handleLogout = async () => {
    await supabase.auth.signOut()
    setUser(null)
    setUserProfile(null) // Clear user profile on logout
    setAlarms([])
    console.log("Auth: User logged out. State reset.")
  }

  const calculateBedtime = () => {
    let hour = Number.parseInt(wakeUpHour)
    const minute = Number.parseInt(wakeUpMinute)

    if (wakeUpPeriod === "PM" && hour !== 12) {
      hour += 12
    } else if (wakeUpPeriod === "AM" && hour === 12) {
      hour = 0
    }

    const wakeUpDate = new Date()
    wakeUpDate.setHours(hour, minute, 0, 0)

    // Suggest 7.5 hours of sleep (450 minutes)
    wakeUpDate.setMinutes(wakeUpDate.getMinutes() - 450)

    const suggestedHour = wakeUpDate.getHours()
    const suggestedMinute = wakeUpDate.getMinutes()
    const suggestedPeriod = suggestedHour >= 12 ? "PM" : "AM"
    const displayHour = suggestedHour > 12 ? suggestedHour - 12 : suggestedHour === 0 ? 12 : suggestedHour

    setSuggestedBedtime(`${displayHour}:${suggestedMinute.toString().padStart(2, "0")} ${suggestedPeriod}`)
  }

  const handleClaimDailyBonus = async () => {
    if (!user || !userProfile) return

    setIsClaimingBonus(true)
    setDailyBonusMessage(null)

    const result = await claimDailyBonus(user.id)

    if (result.success) {
      setDailyBonusMessage({ type: "success", text: result.message })
      // Update local userProfile state
      setUserProfile((prev) =>
        prev
          ? {
              ...prev,
              coins: prev.coins + 25, // Assuming 25 coins for daily bonus
              last_daily_bonus_claim: new Date().toISOString(),
            }
          : null,
      )
    } else {
      setDailyBonusMessage({ type: "error", text: result.message })
    }
    setIsClaimingBonus(false)
  }

  const canClaimDailyBonus = () => {
    if (!userProfile?.has_daily_bonus_feature) return false
    if (!userProfile.last_daily_bonus_claim) return true // Never claimed before

    const lastClaimDate = new Date(userProfile.last_daily_bonus_claim)
    const today = new Date()

    // Normalize dates to compare only day, month, year
    lastClaimDate.setHours(0, 0, 0, 0)
    today.setHours(0, 0, 0, 0)

    return lastClaimDate.getTime() !== today.getTime()
  }

  const availableMissionTypes = userProfile?.unlocked_missions || ["none"]
  const availableBackgrounds = userProfile?.unlocked_backgrounds || ["default"]

  // Handler for toggling shop visibility
  const handleToggleShop = () => {
    console.log("Shop button clicked. Current showShop state:", showShop)
    setShowShop((prevShowShop) => {
      const newState = !prevShowShop
      console.log("setShowShop callback: Previous state:", prevShowShop, "New state:", newState)
      return newState
    })
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 flex items-center justify-center">
        <div className="text-center">
          <AlarmiLogo size={64} animated={true} />
          <p className="mt-4 text-gray-600 dark:text-gray-400">Loading...</p>
        </div>
      </div>
    )
  }

  if (!user) {
    console.log("Rendering AuthForm: User is null.")
    return (
      <div className="relative">
        <AuthForm
          onAuthSuccess={() => {
            // After successful auth, re-check session and load data
            // This will trigger the useEffects to update user and userProfile
            console.log("AuthForm: Authentication successful. Re-evaluating app state.")
          }}
        />
      </div>
    )
  }

  console.log("Rendering Main App: Current state for shop visibility:", {
    showShop,
    user: !!user,
    userProfile: !!userProfile,
  })

  return (
    <div
      className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 p-4 text-gray-900 dark:text-gray-100 transition-filter duration-200"
      style={{ filter: `brightness(${brightnessLevel}%)` }}
    >
      {/* Audio player for voice memos */}
      <audio ref={audioPlayerRef} className="hidden" />

      {/* App Header with Logo */}
      <Card className="text-center bg-gradient-to-r from-blue-600 to-indigo-600 text-white dark:from-gray-700 dark:to-gray-900">
        <CardContent className="pt-6 pb-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <AlarmiLogo size={48} animated={true} />
              <div>
                <h1 className="text-3xl font-bold tracking-wide">Alarmi</h1>
                <p className="text-blue-100 text-sm dark:text-gray-300">Your Smart Alarm Companion</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <ThemeToggle />
              {/* New Settings Button */}
              <Button variant="ghost" size="icon" onClick={() => setIsSettingsOpen(true)}>
                <Settings className="h-[1.2rem] w-[1.2rem]" />
                <span className="sr-only">Settings</span>
              </Button>
              {userProfile && (
                <UserMenu
                  onLogout={handleLogout}
                  userCoins={userProfile.coins}
                  onOpenSettings={() => setIsSettingsOpen(true)}
                />
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="max-w-md mx-auto space-y-6">
        {/* Current Time Display */}
        <Card className="text-center bg-white dark:bg-gray-800">
          <CardContent className="pt-6">
            <div className="text-4xl font-mono font-bold text-gray-800 dark:text-gray-100 mb-2">
              {formatTime(currentTime)}
            </div>
            <div className="text-sm text-gray-600 dark:text-gray-400">{formatDate(currentTime)}</div>
          </CardContent>
        </Card>

        {/* Weather Info */}
        {weatherData && (
          <Card className="bg-white dark:bg-gray-800">
            <CardContent className="flex items-center gap-4 p-4">
              {weatherData.weather[0]?.icon && (
                <img
                  src={`https://openweathermap.org/img/wn/${weatherData.weather[0].icon}@2x.png`}
                  alt={weatherData.weather[0].description}
                  width={64}
                  height={64}
                  className="dark:invert"
                />
              )}
              <div>
                <div className="text-2xl font-bold text-gray-800 dark:text-gray-100">
                  {Math.round(weatherData.main.temp)}°C
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-400 capitalize">
                  {weatherData.weather[0]?.description} in {weatherData.name}
                </div>
                <div className="text-xs text-gray-500 dark:text-gray-500">
                  Feels like {Math.round(weatherData.main.feels_like)}°C
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* In-app Calendar */}
        <AlarmCalendar alarms={alarms} />

        {/* Alarm Notification / Mission */}
        {triggeringAlarm && isMissionActive ? (
          triggeringAlarm.mission_type === "math" ? (
            <MathMission onSolve={dismissAlarm} />
          ) : triggeringAlarm.mission_type === "shake" ? (
            <ShakeMission onSolve={dismissAlarm} />
          ) : (
            <Alert className="border-red-500 bg-red-50 animate-pulse dark:bg-red-900 dark:border-red-700">
              <Volume2 className="h-4 w-4 text-red-600 dark:text-red-300" />
              <AlertDescription className="text-red-800 font-semibold dark:text-red-200">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-bold">{triggeringAlarm.label}</div>
                    <div className="text-sm">{triggeringAlarm.time}</div>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={snoozeAlarm}
                      className="dark:text-gray-100 dark:border-gray-600 bg-transparent"
                    >
                      Snooze
                    </Button>
                    <Button size="sm" onClick={dismissAlarm} className="dark:bg-red-700 dark:hover:bg-red-800">
                      Dismiss
                    </Button>
                  </div>
                </div>
              </AlertDescription>
            </Alert>
          )
        ) : null}

        {/* Daily Bonus Section */}
        {userProfile?.has_daily_bonus_feature && (
          <Card className="bg-white dark:bg-gray-800">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Gift className="h-5 w-5 text-green-500" />
                Daily Bonus
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {dailyBonusMessage && (
                <Alert className={`border-${dailyBonusMessage.type}-500 bg-${dailyBonusMessage.type}-50`}>
                  {dailyBonusMessage.type === "success" ? (
                    <CheckCircle className="h-4 w-4 text-green-600" />
                  ) : (
                    <XCircle className="h-4 w-4 text-red-600" />
                  )}
                  <AlertDescription className={`text-${dailyBonusMessage.type}-800`}>
                    {dailyBonusMessage.text}
                  </AlertDescription>
                </Alert>
              )}
              <Button
                onClick={handleClaimDailyBonus}
                disabled={!canClaimDailyBonus() || isClaimingBonus}
                className="w-full bg-green-600 hover:bg-green-700 text-white"
              >
                {isClaimingBonus ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Claiming...
                  </>
                ) : canClaimDailyBonus() ? (
                  <>
                    <Gift className="h-4 w-4 mr-2" /> Claim Your 25 Coins!
                  </>
                ) : (
                  "Bonus Claimed Today"
                )}
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Shop Button */}
        <Button onClick={handleToggleShop} className="w-full flex items-center gap-2">
          <Coins className="h-5 w-5" />
          {showShop ? "Hide Shop" : "Visit Shop"}
        </Button>

        {/* Shop Section */}
        {showShop && user && userProfile && (
          <Shop
            userId={user.id}
            userCoins={userProfile.coins}
            unlockedMissions={userProfile.unlocked_missions || []}
            unlockedPremiumTones={userProfile.unlocked_premium_tones}
            hasDailyBonusFeature={userProfile.has_daily_bonus_feature}
            unlockedBackgrounds={userProfile.unlocked_backgrounds || []}
          />
        )}

        {/* Bedtime / Wake-up Reminders */}
        <Card className="bg-white dark:bg-gray-800">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Bed className="h-5 w-5" />
              Bedtime Suggestion
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-2">
              <div className="flex-1">
                <Label htmlFor="wakeUpHour">Wake-up Hour</Label>
                <Select value={wakeUpHour} onValueChange={setWakeUpHour}>
                  <SelectTrigger className="dark:bg-gray-700 dark:text-gray-100 dark:border-gray-600">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="dark:bg-gray-700 dark:text-gray-100">
                    {Array.from({ length: 12 }, (_, i) => i + 1).map((hour) => (
                      <SelectItem key={hour} value={hour.toString().padStart(2, "0")}>
                        {hour.toString().padStart(2, "0")}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex-1">
                <Label htmlFor="wakeUpMinute">Wake-up Minute</Label>
                <Select value={wakeUpMinute} onValueChange={setNewWakeUpMinute}>
                  <SelectTrigger className="dark:bg-gray-700 dark:text-gray-100 dark:border-gray-600">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="dark:bg-gray-700 dark:text-gray-100">
                    {Array.from({ length: 60 }, (_, i) => i).map((minute) => (
                      <SelectItem key={minute} value={minute.toString().padStart(2, "0")}>
                        {minute.toString().padStart(2, "0")}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex-1">
                <Label htmlFor="period">Period</Label>
                <Select value={wakeUpPeriod} onValueChange={(value: "AM" | "PM") => setWakeUpPeriod(value)}>
                  <SelectTrigger className="dark:bg-gray-700 dark:text-gray-100 dark:border-gray-600">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="dark:bg-gray-700 dark:text-gray-100">
                    <SelectItem value="AM">AM</SelectItem>
                    <SelectItem value="PM">PM</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <Button onClick={calculateBedtime} className="w-full">
              Suggest Bedtime
            </Button>
            {suggestedBedtime && (
              <Alert className="mt-4 bg-blue-50 border-blue-200 dark:bg-blue-900 dark:border-blue-700">
                <AlertDescription className="text-blue-800 dark:text-blue-200">
                  For a {`7.5`} hour sleep, aim to go to bed by <span className="font-bold">{suggestedBedtime}</span>.
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>

        {/* Add New Alarm */}
        <Card className="bg-white dark:bg-gray-800">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Plus className="h-5 w-5" />
              Add New Alarm
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-2">
              <div className="flex-1">
                <Label htmlFor="hour">Hour</Label>
                <Select value={newAlarmHour} onValueChange={setNewAlarmHour}>
                  <SelectTrigger className="dark:bg-gray-700 dark:text-gray-100 dark:border-gray-600">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="dark:bg-gray-700 dark:text-gray-100">
                    {Array.from({ length: 12 }, (_, i) => i + 1).map((hour) => (
                      <SelectItem key={hour} value={hour.toString()}>
                        {hour}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex-1">
                <Label htmlFor="minute">Minute</Label>
                <Select value={newAlarmMinute} onValueChange={setNewAlarmMinute}>
                  <SelectTrigger className="dark:bg-gray-700 dark:text-gray-100 dark:border-gray-600">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="dark:bg-gray-700 dark:text-gray-100">
                    {Array.from({ length: 60 }, (_, i) => i).map((minute) => (
                      <SelectItem key={minute} value={minute.toString().padStart(2, "0")}>
                        {minute.toString().padStart(2, "0")}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex-1">
                <Label htmlFor="period">Period</Label>
                <Select value={newAlarmPeriod} onValueChange={(value: "AM" | "PM") => setNewAlarmPeriod(value)}>
                  <SelectTrigger className="dark:bg-gray-700 dark:text-gray-100 dark:border-gray-600">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="dark:bg-gray-700 dark:text-gray-100">
                    <SelectItem value="AM">AM</SelectItem>
                    <SelectItem value="PM">PM</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label htmlFor="label">Label (optional)</Label>
              <Input
                id="label"
                placeholder="Wake up, Meeting, etc."
                value={newAlarmLabel}
                onChange={(e) => setNewAlarmLabel(e.target.value)}
                className="dark:bg-gray-700 dark:text-gray-100 dark:border-gray-600"
              />
            </div>
            {/* New: Mission Type Selection */}
            <div>
              <Label htmlFor="missionType">Mission Type</Label>
              <Select
                value={newAlarmMissionType}
                onValueChange={(value: "none" | "math" | "shake") => setNewAlarmMissionType(value)}
              >
                <SelectTrigger className="dark:bg-gray-700 dark:text-gray-100 dark:border-gray-600">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="dark:bg-gray-700 dark:text-gray-100">
                  <SelectItem value="none">None</SelectItem>
                  <SelectItem value="math" disabled={!availableMissionTypes.includes("math")}>
                    Math Puzzle {availableMissionTypes.includes("math") ? "" : "(Locked)"}
                  </SelectItem>
                  <SelectItem value="shake" disabled={!availableMissionTypes.includes("shake")}>
                    Shake to Dismiss {availableMissionTypes.includes("shake") ? "" : "(Locked)"}
                  </SelectItem>
                </SelectContent>
              </Select>
              {!availableMissionTypes.includes(newAlarmMissionType) && newAlarmMissionType !== "none" && (
                <p className="text-sm text-red-500 mt-1">This mission type is locked. Visit the shop to unlock it!</p>
              )}
            </div>
            {/* Voice Memo Section */}
            <div className="space-y-2">
              <Label>Voice Memo (optional)</Label>
              <div className="flex gap-2">
                <Button
                  type="button"
                  onClick={startRecording}
                  disabled={isRecording}
                  className="flex-1"
                  variant={isRecording ? "destructive" : "default"}
                >
                  {isRecording ? (
                    <>
                      <StopCircle className="h-4 w-4 mr-2 animate-pulse" /> Recording...
                    </>
                  ) : (
                    <>
                      <Mic className="h-4 w-4 mr-2" /> Start Recording
                    </>
                  )}
                </Button>
                <Button type="button" onClick={stopRecording} disabled={!isRecording} variant="secondary">
                  <StopCircle className="h-4 w-4" />
                </Button>
              </div>
              {recordedAudioUrl && (
                <div className="flex items-center gap-2 mt-2">
                  <Button type="button" onClick={playRecordedAudio} variant="outline" size="sm">
                    <Play className="h-4 w-4 mr-2" /> Play Memo
                  </Button>
                  <Button type="button" onClick={clearRecordedAudio} variant="ghost" size="sm">
                    <XCircle className="h-4 w-4 mr-2" /> Clear
                  </Button>
                  <span className="text-sm text-gray-500 dark:text-gray-400">Memo recorded!</span>
                </div>
              )}
            </div>
            <Button onClick={addAlarm} className="w-full">
              <Plus className="h-4 w-4 mr-2" />
              Add Alarm
            </Button>
          </CardContent>
        </Card>

        {/* Active Alarms */}
        <Card className="bg-white dark:bg-gray-800">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              Alarms ({alarms.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            {alarms.length === 0 ? (
              <div className="text-center text-gray-500 py-8">No alarms set</div>
            ) : (
              <div className="space-y-3">
                {alarms.map((alarm) => (
                  <div
                    key={alarm.id}
                    className={`flex items-center justify-between p-3 rounded-lg border ${
                      alarm.is_active
                        ? "bg-green-50 border-green-200 dark:bg-green-900 dark:border-green-700"
                        : "bg-gray-50 border-gray-200 dark:bg-gray-700 dark:border-gray-600"
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <Button variant="ghost" size="sm" onClick={() => toggleAlarm(alarm.id)} className="p-1">
                        {alarm.is_active ? (
                          <Volume2 className="h-4 w-4 text-green-600 dark:text-green-300" />
                        ) : (
                          <VolumeX className="h-4 w-4 text-gray-400 dark:text-gray-500" />
                        )}
                      </Button>
                      <div>
                        <div
                          className={`font-mono text-lg ${
                            alarm.is_active ? "text-gray-800 dark:text-gray-100" : "text-gray-400 dark:text-gray-500"
                          }`}
                        >
                          {alarm.time}
                        </div>
                        <div
                          className={`text-sm ${
                            alarm.is_active ? "text-gray-600 dark:text-gray-300" : "text-gray-400 dark:text-gray-500"
                          }`}
                        >
                          {alarm.label}
                          {alarm.voice_memo_url && (
                            <span className="ml-2 text-xs text-blue-500 dark:text-blue-300">(Voice Memo)</span>
                          )}
                          {alarm.mission_type && alarm.mission_type !== "none" && (
                            <span className="ml-2 text-xs text-purple-500 dark:text-purple-300">
                              ({alarm.mission_type === "math" ? "Math Mission" : "Shake Mission"})
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                    <Button variant="destructive" size="sm" onClick={() => deleteAlarm(alarm.id)}>
                      Delete
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Alarm History */}
        <Card className="bg-white dark:bg-gray-800">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              Alarm History
            </CardTitle>
          </CardHeader>
          <CardContent>
            {alarms.filter((a) => a.last_triggered_at).length === 0 ? (
              <div className="text-center text-gray-500 py-8">No alarm history yet</div>
            ) : (
              <div className="space-y-3">
                {alarms
                  .filter((a) => a.last_triggered_at)
                  .sort((a, b) => new Date(b.last_triggered_at!).getTime() - new Date(a.last_triggered_at!).getTime())
                  .map((alarm) => (
                    <div
                      key={alarm.id}
                      className="flex items-center justify-between p-3 rounded-lg border bg-gray-50 dark:bg-gray-700 dark:border-gray-600"
                    >
                      <div>
                        <div className="font-mono text-lg text-gray-800 dark:text-gray-100">{alarm.time}</div>
                        <div className="text-sm text-gray-600 dark:text-gray-300">
                          {alarm.label}
                          {alarm.voice_memo_url && (
                            <span className="ml-2 text-xs text-blue-500 dark:text-blue-300">(Voice Memo)</span>
                          )}
                          {alarm.mission_type && alarm.mission_type !== "none" && (
                            <span className="ml-2 text-xs text-purple-500 dark:text-purple-300">
                              ({alarm.mission_type === "math" ? "Math Mission" : "Shake Mission"})
                            </span>
                          )}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-sm text-gray-500 dark:text-gray-400">Last Triggered:</div>
                        <div className="text-xs text-gray-500 dark:text-gray-400">
                          {new Date(alarm.last_triggered_at!).toLocaleString()}
                        </div>
                      </div>
                    </div>
                  ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
      {user && userProfile && (
        <SettingsDialog
          isOpen={isSettingsOpen}
          onOpenChange={setIsSettingsOpen}
          user={user}
          userProfile={userProfile}
          onLogout={handleLogout}
        />
      )}
    </div>
  )
}

// Wrapper for ThemeProvider
export function AlarmApp() {
  return (
    <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
      <AlarmAppContent />
    </ThemeProvider>
  )
}
