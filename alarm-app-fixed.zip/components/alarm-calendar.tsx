"use client"
import { useState, useMemo } from "react"
import {
  format,
  startOfMonth,
  endOfMonth,
  startOfWeek,
  endOfWeek,
  addMonths,
  subMonths,
  isSameDay,
  isSameMonth,
  parseISO,
} from "date-fns"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight, CalendarIcon } from "lucide-react"

interface Alarm {
  id: string
  time: string
  label: string
  is_active: boolean
  hour: number
  minute: number
  period: "AM" | "PM"
  user_id: string
  last_triggered_at: string | null
  voice_memo_url: string | null
  mission_type: string | null
}

interface AlarmCalendarProps {
  alarms: Alarm[]
}

export function AlarmCalendar({ alarms }: AlarmCalendarProps) {
  const [currentMonth, setCurrentMonth] = useState(new Date())

  const daysInMonth = useMemo(() => {
    const start = startOfWeek(startOfMonth(currentMonth))
    const end = endOfWeek(endOfMonth(currentMonth))
    const days = []
    let day = start

    while (day <= end) {
      days.push(day)
      day = new Date(day.setDate(day.getDate() + 1))
    }
    return days
  }, [currentMonth])

  const alarmsByDay = useMemo(() => {
    const map = new Map<string, Alarm[]>()
    alarms.forEach((alarm) => {
      // For simplicity, assuming alarms are set for "today" if active, or using last_triggered_at for history
      // A more robust solution would involve recurring alarms and specific dates
      const dateKey =
        alarm.is_active && alarm.hour !== undefined && alarm.minute !== undefined
          ? format(new Date(), "yyyy-MM-dd") // Active alarms are for today
          : alarm.last_triggered_at
            ? format(parseISO(alarm.last_triggered_at), "yyyy-MM-dd")
            : null

      if (dateKey) {
        if (!map.has(dateKey)) {
          map.set(dateKey, [])
        }
        map.get(dateKey)?.push(alarm)
      }
    })
    return map
  }, [alarms])

  const nextMonth = () => {
    setCurrentMonth(addMonths(currentMonth, 1))
  }

  const prevMonth = () => {
    setCurrentMonth(subMonths(currentMonth, 1))
  }

  const hasAlarm = (day: Date) => {
    const dayKey = format(day, "yyyy-MM-dd")
    return (
      alarmsByDay.has(dayKey) &&
      (alarmsByDay.get(dayKey)?.some((a) => a.is_active) || alarmsByDay.get(dayKey)?.some((a) => a.last_triggered_at))
    )
  }

  return (
    <Card className="bg-white dark:bg-gray-800">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="flex items-center gap-2 text-lg">
          <CalendarIcon className="h-5 w-5" />
          Calendar
        </CardTitle>
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" onClick={prevMonth}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <span className="font-semibold text-gray-800 dark:text-gray-100">{format(currentMonth, "MMMM yyyy")}</span>
          <Button variant="ghost" size="icon" onClick={nextMonth}>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-7 text-center text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">
          <div>Sun</div>
          <div>Mon</div>
          <div>Tue</div>
          <div>Wed</div>
          <div>Thu</div>
          <div>Fri</div>
          <div>Sat</div>
        </div>
        <div className="grid grid-cols-7 gap-1">
          {daysInMonth.map((day, index) => (
            <div
              key={index}
              className={`relative p-2 rounded-md text-center text-sm
                ${!isSameMonth(day, currentMonth) ? "text-gray-400 dark:text-gray-600" : "text-gray-800 dark:text-gray-100"}
                ${isSameDay(day, new Date()) ? "bg-blue-100 dark:bg-blue-900 font-bold" : ""}
                ${hasAlarm(day) ? "bg-yellow-100 dark:bg-yellow-900 border border-yellow-300 dark:border-yellow-700" : ""}
              `}
            >
              {format(day, "d")}
              {hasAlarm(day) && (
                <span className="absolute top-1 right-1 h-2 w-2 rounded-full bg-red-500" title="Alarm set"></span>
              )}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
