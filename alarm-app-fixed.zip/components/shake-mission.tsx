"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { CheckCircle, XCircle, Activity } from "lucide-react" // Ensure 'Activity' is imported

interface ShakeMissionProps {
  onSolve: () => void
  onFail?: () => void
}

export function ShakeMission({ onSolve, onFail }: ShakeMissionProps) {
  const [shakeCount, setShakeCount] = useState(0)
  const [message, setMessage] = useState<{ type: "error" | "success"; text: string } | null>(null)
  const requiredShakes = 5 // Example: 5 shakes to dismiss

  useEffect(() => {
    let last_x: number | null = null
    let last_y: number | null = null
    let last_z: number | null = null
    const shakeThreshold = 15 // Adjust this value for sensitivity

    const handleDeviceMotion = (event: DeviceMotionEvent) => {
      const acceleration = event.accelerationIncludingGravity
      if (!acceleration || acceleration.x === null || acceleration.y === null || acceleration.z === null) {
        return
      }

      const { x, y, z } = acceleration

      if (last_x === null || last_y === null || last_z === null) {
        last_x = x
        last_y = y
        last_z = z
        return
      }

      const deltaX = Math.abs(x - last_x)
      const deltaY = Math.abs(y - last_y)
      const deltaZ = Math.abs(z - last_z)

      if (deltaX > shakeThreshold || deltaY > shakeThreshold || deltaZ > shakeThreshold) {
        setShakeCount((prev) => prev + 1)
        setMessage(null) // Clear message on new shake
      }

      last_x = x
      last_y = y
      last_z = z
    }

    if (typeof window !== "undefined" && "DeviceMotionEvent" in window) {
      window.addEventListener("devicemotion", handleDeviceMotion)
    } else {
      setMessage({ type: "error", text: "Device motion not supported on this device." })
    }

    return () => {
      if (typeof window !== "undefined" && "DeviceMotionEvent" in window) {
        window.removeEventListener("devicemotion", handleDeviceMotion)
      }
    }
  }, [])

  useEffect(() => {
    if (shakeCount >= requiredShakes) {
      setMessage({ type: "success", text: "Mission complete! Alarm dismissed." })
      setTimeout(onSolve, 1000) // Give a moment to see success message
    }
  }, [shakeCount, requiredShakes, onSolve])

  return (
    <Card className="border-purple-500 bg-purple-50 animate-pulse">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-purple-800">
          <Activity className="h-5 w-5" /> {/* Use 'Activity' icon */}
          Alarm Mission: Shake to Dismiss!
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-lg font-semibold text-purple-900 text-center">
          Shake your device {requiredShakes - shakeCount} more times!
        </p>
        {message && (
          <Alert className={`border-${message.type}-500 bg-${message.type}-50`}>
            {message.type === "success" ? (
              <CheckCircle className="h-4 w-4 text-green-600" />
            ) : (
              <XCircle className="h-4 w-4 text-red-600" />
            )}
            <AlertDescription className={`text-${message.type}-800`}>{message.text}</AlertDescription>
          </Alert>
        )}
      </CardContent>
    </Card>
  )
}
