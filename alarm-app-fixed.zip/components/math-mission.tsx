"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { CheckCircle, XCircle, Brain } from "lucide-react"

interface MathMissionProps {
  onSolve: () => void
  onFail?: () => void
}

export function MathMission({ onSolve, onFail }: MathMissionProps) {
  const [num1, setNum1] = useState(0)
  const [num2, setNum2] = useState(0)
  const [operator, setOperator] = useState<"+" | "-" | "*">("+")
  const [answer, setAnswer] = useState("")
  const [correctAnswer, setCorrectAnswer] = useState(0)
  const [message, setMessage] = useState<{ type: "error" | "success"; text: string } | null>(null)

  const generateProblem = () => {
    const operators = ["+", "-", "*"]
    const op = operators[Math.floor(Math.random() * operators.length)] as "+" | "-" | "*"
    let n1 = Math.floor(Math.random() * 10) + 1 // 1-10
    let n2 = Math.floor(Math.random() * 10) + 1 // 1-10

    // Ensure division results in whole numbers if we were to add it
    // For subtraction, ensure positive result
    if (op === "-") {
      if (n1 < n2) [n1, n2] = [n2, n1] // Swap to ensure n1 >= n2
    }

    setNum1(n1)
    setNum2(n2)
    setOperator(op)
    setAnswer("")
    setMessage(null)

    let correct: number
    switch (op) {
      case "+":
        correct = n1 + n2
        break
      case "-":
        correct = n1 - n2
        break
      case "*":
        correct = n1 * n2
        break
      default:
        correct = 0
    }
    setCorrectAnswer(correct)
  }

  useEffect(() => {
    generateProblem()
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (Number.parseInt(answer) === correctAnswer) {
      setMessage({ type: "success", text: "Correct! Alarm dismissed." })
      setTimeout(onSolve, 1000) // Give a moment to see success message
    } else {
      setMessage({ type: "error", text: "Incorrect. Try again!" })
      setAnswer("") // Clear input for retry
    }
  }

  return (
    <Card className="border-yellow-500 bg-yellow-50 animate-pulse">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-yellow-800">
          <Brain className="h-5 w-5" />
          Alarm Mission: Solve Math Problem!
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-lg font-semibold text-yellow-900 text-center">
          What is {num1} {operator} {num2}?
        </p>
        <form onSubmit={handleSubmit} className="space-y-3">
          <Input
            type="number"
            placeholder="Your answer"
            value={answer}
            onChange={(e) => setAnswer(e.target.value)}
            className="text-center text-lg"
            required
            autoFocus
          />
          {message && (
            <Alert className={`border-${message.type}-500 bg-${message.type}-50`}>
              {message.type === "success" ? (
                <CheckCircle className="h-4 w-4 text-green-600" />
              ) : (
                <XCircle className="h-4 w-4 text-red-600" />
              )}
              <AlertDescription className={`text-${message.type}-800`}>{message.text}</AlertDescription>
            </Alert>
          )}
          <Button type="submit" className="w-full bg-yellow-600 hover:bg-yellow-700 text-white">
            Submit Answer
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
