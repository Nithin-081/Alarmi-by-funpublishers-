"use client"

interface AlarmiLogoProps {
  size?: number
  className?: string
  animated?: boolean
}

export function AlarmiLogo({ size = 40, className = "", animated = true }: AlarmiLogoProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" className={className} xmlns="http://www.w3.org/2000/svg">
      {/* Outer Ring */}
      <circle
        cx="50"
        cy="50"
        r="45"
        fill="none"
        stroke="url(#gradient1)"
        strokeWidth="3"
        className={animated ? "animate-pulse" : ""}
      />

      {/* Inner Clock Face */}
      <circle cx="50" cy="50" r="35" fill="url(#gradient2)" stroke="#1e40af" strokeWidth="2" />

      {/* Clock Numbers (12, 3, 6, 9) */}
      <text x="50" y="25" textAnchor="middle" className="fill-white text-xs font-bold">
        12
      </text>
      <text x="75" y="55" textAnchor="middle" className="fill-white text-xs font-bold">
        3
      </text>
      <text x="50" y="80" textAnchor="middle" className="fill-white text-xs font-bold">
        6
      </text>
      <text x="25" y="55" textAnchor="middle" className="fill-white text-xs font-bold">
        9
      </text>

      {/* Clock Hands */}
      <line
        x1="50"
        y1="50"
        x2="50"
        y2="30"
        stroke="#fbbf24"
        strokeWidth="3"
        strokeLinecap="round"
        className={animated ? "animate-spin" : ""}
        style={{ transformOrigin: "50px 50px", animationDuration: "2s" }}
      />
      <line x1="50" y1="50" x2="65" y2="50" stroke="#fbbf24" strokeWidth="2" strokeLinecap="round" />

      {/* Center Dot */}
      <circle cx="50" cy="50" r="3" fill="#fbbf24" />

      {/* Alarm Bells */}
      <path
        d="M20 35 Q15 30 10 35 Q15 40 20 35"
        fill="#ef4444"
        className={animated ? "animate-bounce" : ""}
        style={{ animationDuration: "1s", animationDelay: "0.5s" }}
      />
      <path
        d="M80 35 Q85 30 90 35 Q85 40 80 35"
        fill="#ef4444"
        className={animated ? "animate-bounce" : ""}
        style={{ animationDuration: "1s", animationDelay: "0.7s" }}
      />

      {/* Sound Waves */}
      <path
        d="M5 45 Q10 40 5 35"
        fill="none"
        stroke="#fbbf24"
        strokeWidth="2"
        strokeLinecap="round"
        className={animated ? "animate-pulse" : ""}
        style={{ animationDelay: "0.2s" }}
      />
      <path
        d="M95 45 Q90 40 95 35"
        fill="none"
        stroke="#fbbf24"
        strokeWidth="2"
        strokeLinecap="round"
        className={animated ? "animate-pulse" : ""}
        style={{ animationDelay: "0.4s" }}
      />

      {/* Letter "i" Integration */}
      <circle
        cx="50"
        cy="15"
        r="3"
        fill="#fbbf24"
        className={animated ? "animate-ping" : ""}
        style={{ animationDelay: "1s" }}
      />

      {/* Gradients */}
      <defs>
        <linearGradient id="gradient1" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#3b82f6" />
          <stop offset="100%" stopColor="#6366f1" />
        </linearGradient>
        <linearGradient id="gradient2" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#1e40af" />
          <stop offset="100%" stopColor="#3730a3" />
        </linearGradient>
      </defs>
    </svg>
  )
}
