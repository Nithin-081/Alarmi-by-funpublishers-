export const metadata = {
  title: "Alarmi - Smart Alarm App",
  description: "Your smart alarm companion for better wake-ups",
}

import AlarmApp from "../alarm-app"

export default function Page() {
  return <AlarmApp />
}
