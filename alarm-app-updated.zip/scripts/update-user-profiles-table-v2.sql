-- Add columns for new shop items to user_profiles table
ALTER TABLE user_profiles
ADD COLUMN unlocked_premium_tones BOOLEAN DEFAULT FALSE;

ALTER TABLE user_profiles
ADD COLUMN has_daily_bonus_feature BOOLEAN DEFAULT FALSE;

ALTER TABLE user_profiles
ADD COLUMN last_daily_bonus_claim TIMESTAMP WITH TIME ZONE;

ALTER TABLE user_profiles
ADD COLUMN unlocked_backgrounds TEXT[] DEFAULT ARRAY['default']; -- 'default' background is always available
