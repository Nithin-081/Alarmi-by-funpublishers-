-- Add coins column to user_profiles table
ALTER TABLE user_profiles
ADD COLUMN coins INTEGER DEFAULT 0;

-- Add unlocked_missions column to user_profiles table
-- This will store an array of mission types the user has unlocked (e.g., {'none', 'math', 'shake'})
ALTER TABLE user_profiles
ADD COLUMN unlocked_missions TEXT[] DEFAULT ARRAY['none'];
