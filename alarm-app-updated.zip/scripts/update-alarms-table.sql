-- Add last_triggered_at column to alarms table
ALTER TABLE alarms
ADD COLUMN last_triggered_at TIMESTAMP WITH TIME ZONE;
