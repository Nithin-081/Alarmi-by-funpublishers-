"use client"

import type React from "react"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Coins, CheckCircle, XCircle, Music, ImageIcon, Gift } from "lucide-react" // Import new icons
import { useState } from "react"
import { unlockMission, unlockFeature } from "@/actions/user-actions" // Import unlockFeature

interface ShopProps {
  userId: string
  userCoins: number
  unlockedMissions: string[]
  unlockedPremiumTones: boolean // New prop
  hasDailyBonusFeature: boolean // New prop
  unlockedBackgrounds: string[] // New prop
}

interface ShopItem {
  id: string
  name: string
  description: string
  cost: number
  type: "mission" | "tone-pack" | "feature" | "cosmetic" // Extended item types
  value: string | boolean | string[] // The actual value to unlock (e.g., 'math', 'shake', true, ['bg-blue'])
  column?: string // Optional: database column to update for generic features
  icon: React.ElementType // Icon for the shop item
}

const shopItems: ShopItem[] = [
  {
    id: "mission-math",
    name: "Math Mission",
    description: "Unlock math puzzles to dismiss your alarms.",
    cost: 50,
    type: "mission",
    value: "math",
    icon: CheckCircle,
  },
  {
    id: "mission-shake",
    name: "Shake Mission",
    description: "Unlock shake challenges to dismiss your alarms.",
    cost: 75,
    type: "mission",
    value: "shake",
    icon: CheckCircle,
  },
  {
    id: "premium-tones",
    name: "Premium Tones Pack",
    description: "Access a collection of exclusive alarm tones.",
    cost: 100,
    type: "tone-pack",
    value: true, // Unlocks the feature (boolean)
    column: "unlocked_premium_tones",
    icon: Music,
  },
  {
    id: "daily-bonus-feature",
    name: "Daily Coin Bonus",
    description: "Unlock a daily bonus of 25 coins!",
    cost: 150,
    type: "feature",
    value: true, // Unlocks the feature (boolean)
    column: "has_daily_bonus_feature",
    icon: Gift,
  },
  {
    id: "custom-backgrounds",
    name: "Custom Backgrounds",
    description: "Personalize your app with unique backgrounds.",
    cost: 120,
    type: "cosmetic",
    value: ["default", "gradient-blue-purple", "dark-forest"], // Example backgrounds
    column: "unlocked_backgrounds",
    icon: ImageIcon,
  },
  // Add more items here later
]

export function Shop({
  userId,
  userCoins,
  unlockedMissions,
  unlockedPremiumTones,
  hasDailyBonusFeature,
  unlockedBackgrounds,
}: ShopProps) {
  const [message, setMessage] = useState<{ type: "error" | "success"; text: string } | null>(null)
  const [isBuying, setIsBuying] = useState(false)

  const handlePurchase = async (item: ShopItem) => {
    if (isBuying) return

    setIsBuying(true)
    setMessage(null)

    let result: { success: boolean; message: string }

    if (item.type === "mission") {
      result = await unlockMission(userId, item.value as string, item.cost)
    } else if (item.type === "tone-pack" || item.type === "feature" || item.type === "cosmetic") {
      if (!item.column) {
        setMessage({ type: "error", text: "Invalid shop item configuration." })
        setIsBuying(false)
        return
      }
      result = await unlockFeature(userId, item.name, item.cost, item.column as any, item.value)
    } else {
      setMessage({ type: "error", text: "Unknown item type." })
      setIsBuying(false)
      return
    }

    if (result.success) {
      setMessage({ type: "success", text: result.message })
    } else {
      setMessage({ type: "error", text: result.message })
    }
    setIsBuying(false)
  }

  const isItemUnlocked = (item: ShopItem) => {
    if (item.type === "mission") {
      return unlockedMissions.includes(item.value as string)
    }
    if (item.type === "tone-pack") {
      return unlockedPremiumTones === (item.value as boolean)
    }
    if (item.type === "feature") {
      return hasDailyBonusFeature === (item.value as boolean)
    }
    if (item.type === "cosmetic") {
      // Check if all values in item.value are present in unlockedBackgrounds
      return (item.value as string[]).every((val) => unlockedBackgrounds.includes(val))
    }
    return false
  }

  return (
    <Card className="bg-white dark:bg-gray-800">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Coins className="h-5 w-5" />
          Alarmi Shop
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="text-lg font-semibold text-gray-800 dark:text-gray-100">
          Your Coins: <span className="text-yellow-500">{userCoins}</span>
        </div>

        {message && (
          <Alert className={`border-${message.type}-500 bg-${message.type}-50`}>
            {message.type === "success" ? (
              <CheckCircle className="h-4 w-4 text-green-600" />
            ) : (
              <XCircle className="h-4 w-4 text-red-600" />
            )}
            <AlertDescription className={`text-${message.type}-800`}>{message.text}</AlertDescription>
          </Alert>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {shopItems.map((item) => {
            const unlocked = isItemUnlocked(item)
            const canAfford = userCoins >= item.cost

            return (
              <Card
                key={item.id}
                className={`p-4 ${unlocked ? "border-green-500 bg-green-50 dark:bg-green-900/50" : "dark:bg-gray-700"}`}
              >
                <h3 className="font-bold text-lg flex items-center gap-2">
                  <item.icon className="h-5 w-5" /> {item.name}
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-300 mb-2">{item.description}</p>
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-yellow-500 flex items-center gap-1">
                    <Coins className="h-4 w-4" /> {item.cost}
                  </span>
                  <Button
                    onClick={() => handlePurchase(item)}
                    disabled={unlocked || !canAfford || isBuying}
                    className={`${unlocked ? "bg-green-600 hover:bg-green-600" : ""} ${!canAfford ? "opacity-50 cursor-not-allowed" : ""}`}
                  >
                    {isBuying ? "Buying..." : unlocked ? "Unlocked" : "Buy"}
                  </Button>
                </div>
              </Card>
            )
          })}
        </div>
      </CardContent>
    </Card>
  )
}
