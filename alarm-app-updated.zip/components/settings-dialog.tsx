"use client"

import { Card } from "@/components/ui/card"

import type React from "react"
import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, CheckCircle, XCircle, User, Lock, Palette, Trash2 } from "lucide-react"
import { ThemeToggle } from "./theme-toggle"
import { updateUserProfile, initiatePasswordReset, deleteUserAccount } from "@/actions/settings-actions"
import { useActionState } from "react"
import type { User as SupabaseUser } from "@supabase/supabase-js"

interface UserProfile {
  id: string
  username: string | null
  email: string | null
  full_name: string | null
  coins: number
  unlocked_missions: string[] | null
}

interface SettingsDialogProps {
  isOpen: boolean
  onOpenChange: (open: boolean) => void
  user: SupabaseUser | null
  userProfile: UserProfile | null
  onLogout: () => void // Callback to handle logout after account deletion
}

export function SettingsDialog({ isOpen, onOpenChange, user, userProfile, onLogout }: SettingsDialogProps) {
  const [activeTab, setActiveTab] = useState("profile")

  // Profile form states
  const [username, setUsername] = useState(userProfile?.username || "")
  const [fullName, setFullName] = useState(userProfile?.full_name || "")
  const [email, setEmail] = useState(userProfile?.email || user?.email || "")

  // Password reset state
  const [passwordResetEmail, setPasswordResetEmail] = useState(user?.email || "")

  // Delete account state
  const [confirmDelete, setConfirmDelete] = useState("")
  const [showDeleteConfirmation, setShowDeleteConfirmation] = useState(false)

  // Server action states
  const [profileState, profileAction, isProfilePending] = useActionState(updateUserProfile, {
    success: false,
    message: "",
  })
  const [passwordState, passwordAction, isPasswordPending] = useActionState(initiatePasswordReset, {
    success: false,
    message: "",
  })
  const [deleteState, deleteAction, isDeletePending] = useActionState(deleteUserAccount, {
    success: false,
    message: "",
  })

  // Effect to update form fields when dialog opens or user/profile data changes
  useEffect(() => {
    if (userProfile) {
      setUsername(userProfile.username || "")
      setFullName(userProfile.full_name || "")
      setEmail(userProfile.email || user?.email || "")
    } else if (user) {
      setEmail(user.email || "")
    }
    if (user) {
      setPasswordResetEmail(user.email || "")
    }
    // Reset confirmation for delete account when dialog opens
    setShowDeleteConfirmation(false)
    setConfirmDelete("")
  }, [user, userProfile, isOpen])

  // Effects to clear messages after a few seconds
  useEffect(() => {
    if (profileState.success || profileState.message) {
      const timer = setTimeout(() => profileAction(null), 3000) // Clear message after 3 seconds
      return () => clearTimeout(timer)
    }
  }, [profileState, profileAction])

  useEffect(() => {
    if (passwordState.success || passwordState.message) {
      const timer = setTimeout(() => passwordAction(null), 3000) // Clear message after 3 seconds
      return () => clearTimeout(timer)
    }
  }, [passwordState, passwordAction])

  useEffect(() => {
    if (deleteState.success) {
      onLogout() // Log out user after successful deletion
    } else if (deleteState.message) {
      const timer = setTimeout(() => deleteAction(null), 3000) // Clear message after 3 seconds
      return () => clearTimeout(timer)
    }
  }, [deleteState, onLogout, deleteAction])

  const handleProfileSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user) return
    profileAction(user.id, { username, full_name: fullName, email })
  }

  const handlePasswordReset = async (e: React.FormEvent) => {
    e.preventDefault()
    passwordAction(passwordResetEmail)
  }

  const handleDeleteAccount = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user) return
    if (confirmDelete === "DELETE MY ACCOUNT") {
      deleteAction(user.id)
    } else {
      // Manually set an error message if confirmation text is wrong
      deleteAction(null, { success: false, message: "Please type 'DELETE MY ACCOUNT' to confirm." })
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px] dark:bg-gray-800 dark:text-gray-100">
        <DialogHeader>
          <DialogTitle>Settings</DialogTitle>
          <DialogDescription>Manage your account and app preferences.</DialogDescription>
        </DialogHeader>
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="profile">
              <User className="h-4 w-4 mr-2" /> Profile
            </TabsTrigger>
            <TabsTrigger value="security">
              <Lock className="h-4 w-4 mr-2" /> Security
            </TabsTrigger>
            <TabsTrigger value="appearance">
              <Palette className="h-4 w-4 mr-2" /> Appearance
            </TabsTrigger>
          </TabsList>

          {/* Profile Tab Content */}
          <TabsContent value="profile" className="mt-4 space-y-4">
            <form onSubmit={handleProfileSubmit} className="space-y-4">
              <div>
                <Label htmlFor="username">Username</Label>
                <Input
                  id="username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="dark:bg-gray-700 dark:text-gray-100 dark:border-gray-600"
                />
              </div>
              <div>
                <Label htmlFor="fullName">Full Name</Label>
                <Input
                  id="fullName"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="dark:bg-gray-700 dark:text-gray-100 dark:border-gray-600"
                />
              </div>
              <div>
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="dark:bg-gray-700 dark:text-gray-100 dark:border-gray-600"
                />
              </div>
              {profileState.message && (
                <Alert
                  className={`border-${profileState.success ? "green" : "red"}-500 bg-${profileState.success ? "green" : "red"}-50`}
                >
                  {profileState.success ? (
                    <CheckCircle className="h-4 w-4 text-green-600" />
                  ) : (
                    <XCircle className="h-4 w-4 text-red-600" />
                  )}
                  <AlertDescription className={`text-${profileState.success ? "green" : "red"}-800`}>
                    {profileState.message}
                  </AlertDescription>
                </Alert>
              )}
              <Button type="submit" className="w-full" disabled={isProfilePending}>
                {isProfilePending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Saving...
                  </>
                ) : (
                  "Save Changes"
                )}
              </Button>
            </form>
          </TabsContent>

          {/* Security Tab Content */}
          <TabsContent value="security" className="mt-4 space-y-4">
            <Card className="p-4 dark:bg-gray-700">
              <h3 className="font-semibold mb-2">Change Password</h3>
              <p className="text-sm text-gray-600 dark:text-gray-300 mb-3">Send a password reset link to your email.</p>
              <form onSubmit={handlePasswordReset} className="space-y-3">
                <Input
                  type="email"
                  placeholder="Your email"
                  value={passwordResetEmail}
                  onChange={(e) => setPasswordResetEmail(e.target.value)}
                  className="dark:bg-gray-600 dark:text-gray-100 dark:border-gray-500"
                />
                {passwordState.message && (
                  <Alert
                    className={`border-${passwordState.success ? "green" : "red"}-500 bg-${passwordState.success ? "green" : "red"}-50`}
                  >
                    {passwordState.success ? (
                      <CheckCircle className="h-4 w-4 text-green-600" />
                    ) : (
                      <XCircle className="h-4 w-4 text-red-600" />
                    )}
                    <AlertDescription className={`text-${passwordState.success ? "green" : "red"}-800`}>
                      {passwordState.message}
                    </AlertDescription>
                  </Alert>
                )}
                <Button type="submit" className="w-full" disabled={isPasswordPending}>
                  {isPasswordPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Sending...
                    </>
                  ) : (
                    "Send Reset Link"
                  )}
                </Button>
              </form>
            </Card>

            <Card className="p-4 border-red-500 bg-red-50 dark:bg-red-900/50 dark:border-red-700">
              <h3 className="font-semibold text-red-800 dark:text-red-200 mb-2">Delete Account</h3>
              <p className="text-sm text-red-700 dark:text-red-300 mb-3">
                Permanently delete your account and all associated data. This action cannot be undone.
              </p>
              {!showDeleteConfirmation ? (
                <Button variant="destructive" onClick={() => setShowDeleteConfirmation(true)} className="w-full">
                  <Trash2 className="h-4 w-4 mr-2" /> Delete My Account
                </Button>
              ) : (
                <form onSubmit={handleDeleteAccount} className="space-y-3">
                  <Label htmlFor="confirmDelete" className="text-red-800 dark:text-red-200">
                    Type "DELETE MY ACCOUNT" to confirm
                  </Label>
                  <Input
                    id="confirmDelete"
                    value={confirmDelete}
                    onChange={(e) => setConfirmDelete(e.target.value)}
                    className="dark:bg-red-800 dark:text-red-100 dark:border-red-600"
                  />
                  {deleteState.message && (
                    <Alert
                      className={`border-${deleteState.success ? "green" : "red"}-500 bg-${deleteState.success ? "green" : "red"}-50`}
                    >
                      {deleteState.success ? (
                        <CheckCircle className="h-4 w-4 text-green-600" />
                      ) : (
                        <XCircle className="h-4 w-4 text-red-600" />
                      )}
                      <AlertDescription className={`text-${deleteState.success ? "green" : "red"}-800`}>
                        {deleteState.message}
                      </AlertDescription>
                    </Alert>
                  )}
                  <div className="flex gap-2">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setShowDeleteConfirmation(false)}
                      className="flex-1 dark:text-gray-100 dark:border-gray-600 bg-transparent"
                      disabled={isDeletePending}
                    >
                      Cancel
                    </Button>
                    <Button type="submit" variant="destructive" className="flex-1" disabled={isDeletePending}>
                      {isDeletePending ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Deleting...
                        </>
                      ) : (
                        "Confirm Delete"
                      )}
                    </Button>
                  </div>
                </form>
              )}
            </Card>
          </TabsContent>

          {/* Appearance Tab Content */}
          <TabsContent value="appearance" className="mt-4 space-y-4">
            <Card className="p-4 dark:bg-gray-700">
              <h3 className="font-semibold mb-2">Theme</h3>
              <p className="text-sm text-gray-600 dark:text-gray-300 mb-3">Choose your preferred app theme.</p>
              <div className="flex justify-center">
                <ThemeToggle />
              </div>
            </Card>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  )
}
