"use server"

import { supabase } from "@/lib/supabase"
import { revalidatePath } from "next/cache"
import type { Database } from "@/lib/database.types" // Declare the Database variable

export async function updateUserCoins(userId: string, amount: number) {
  const { data: profile, error: fetchError } = await supabase
    .from("user_profiles")
    .select("coins")
    .eq("id", userId)
    .single()

  if (fetchError || !profile) {
    console.error("Error fetching user profile:", fetchError?.message)
    return { success: false, message: "User profile not found." }
  }

  const newCoins = profile.coins + amount
  const { error } = await supabase.from("user_profiles").update({ coins: newCoins }).eq("id", userId)

  if (error) {
    console.error("Error updating user coins:", error.message)
    return { success: false, message: "Failed to update coins." }
  }

  revalidatePath("/") // Revalidate to show updated coins
  return { success: true, message: `Coins updated. New balance: ${newCoins}` }
}

export async function unlockMission(userId: string, missionType: string, cost: number) {
  const { data: profile, error: fetchError } = await supabase
    .from("user_profiles")
    .select("coins, unlocked_missions")
    .eq("id", userId)
    .single()

  if (fetchError || !profile) {
    console.error("Error fetching user profile:", fetchError?.message)
    return { success: false, message: "User profile not found." }
  }

  if (profile.coins < cost) {
    return { success: false, message: "Not enough coins!" }
  }

  if (profile.unlocked_missions?.includes(missionType)) {
    return { success: false, message: "Mission already unlocked!" }
  }

  const newCoins = profile.coins - cost
  const newUnlockedMissions = [...(profile.unlocked_missions || []), missionType]

  const { error } = await supabase
    .from("user_profiles")
    .update({ coins: newCoins, unlocked_missions: newUnlockedMissions })
    .eq("id", userId)

  if (error) {
    console.error("Error unlocking mission:", error.message)
    return { success: false, message: "Failed to unlock mission." }
  }

  revalidatePath("/") // Revalidate to show updated coins and unlocked missions
  return { success: true, message: `Mission '${missionType}' unlocked! Coins remaining: ${newCoins}` }
}

// New server action to unlock general features/cosmetics
export async function unlockFeature(
  userId: string,
  featureName: string,
  cost: number,
  columnToUpdate: keyof Database["public"]["Tables"]["user_profiles"]["Update"],
  valueToSet: any, // Can be boolean or array
) {
  const { data: profile, error: fetchError } = await supabase
    .from("user_profiles")
    .select(`coins, ${String(columnToUpdate)}`)
    .eq("id", userId)
    .single()

  if (fetchError || !profile) {
    console.error("Error fetching user profile:", fetchError?.message)
    return { success: false, message: "User profile not found." }
  }

  if (profile.coins < cost) {
    return { success: false, message: "Not enough coins!" }
  }

  // Check if feature is already unlocked (for boolean or array types)
  if (typeof valueToSet === "boolean" && profile[columnToUpdate] === valueToSet) {
    return { success: false, message: `${featureName} already unlocked!` }
  }
  if (
    Array.isArray(valueToSet) &&
    Array.isArray(profile[columnToUpdate]) &&
    valueToSet.every((v) => (profile[columnToUpdate] as string[]).includes(v))
  ) {
    return { success: false, message: `${featureName} already unlocked!` }
  }

  const newCoins = profile.coins - cost
  const updatePayload: Partial<Database["public"]["Tables"]["user_profiles"]["Update"]> = {
    coins: newCoins,
    [columnToUpdate]: valueToSet,
  }

  const { error } = await supabase.from("user_profiles").update(updatePayload).eq("id", userId)

  if (error) {
    console.error(`Error unlocking ${featureName}:`, error.message)
    return { success: false, message: `Failed to unlock ${featureName}: ${error.message}` }
  }

  revalidatePath("/")
  return { success: true, message: `${featureName} unlocked! Coins remaining: ${newCoins}` }
}

// New server action to claim daily bonus
export async function claimDailyBonus(userId: string) {
  const { data: profile, error: fetchError } = await supabase
    .from("user_profiles")
    .select("coins, last_daily_bonus_claim")
    .eq("id", userId)
    .single()

  if (fetchError || !profile) {
    console.error("Error fetching user profile:", fetchError?.message)
    return { success: false, message: "User profile not found." }
  }

  const today = new Date()
  today.setHours(0, 0, 0, 0) // Normalize to start of day

  if (profile.last_daily_bonus_claim) {
    const lastClaimDate = new Date(profile.last_daily_bonus_claim)
    lastClaimDate.setHours(0, 0, 0, 0) // Normalize to start of day

    if (lastClaimDate.getTime() === today.getTime()) {
      return { success: false, message: "Daily bonus already claimed today!" }
    }
  }

  const BONUS_AMOUNT = 25 // Define bonus amount
  const newCoins = profile.coins + BONUS_AMOUNT

  const { error } = await supabase
    .from("user_profiles")
    .update({ coins: newCoins, last_daily_bonus_claim: new Date().toISOString() })
    .eq("id", userId)

  if (error) {
    console.error("Error claiming daily bonus:", error.message)
    return { success: false, message: "Failed to claim daily bonus." }
  }

  revalidatePath("/")
  return { success: true, message: `Daily bonus claimed! You received ${BONUS_AMOUNT} coins. New balance: ${newCoins}` }
}
